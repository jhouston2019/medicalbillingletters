# Missing Operations / Required Procedures (worksheet)
- Panel R&I/R&R details: {{panel}}
- Seam sealer/corrosion protection: {{details}}
- OEM ADAS calibration requirements: {{systems}}
- Pre-/Post-scan documentation (attach reports)
- Blend/tint/time for color match: {{hours}}
- Alignment/sublet/certified welding notes
