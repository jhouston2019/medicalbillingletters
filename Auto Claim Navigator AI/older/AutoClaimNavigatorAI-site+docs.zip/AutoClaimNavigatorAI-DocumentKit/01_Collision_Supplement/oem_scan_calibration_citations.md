# OEM / Scan / Calibration Citations (placeholders)
- {{Make}} Position Statement on Pre-/Post-Repair Scanning, ref: {{doc/id}}
- ADAS Calibration after {{component}} replacement, ref: {{doc/id}}
- Weld procedures & corrosion protection, ref: {{doc/id}}
(Replace with the actual citations your shop uses. Attach PDFs where possible.)
