# Labor Rate & Paint Materials Support (notes)
- Shop posted rates: Body ${{BodyRate}}, Refinish ${{RefinishRate}}, Frame ${{FrameRate}}
- Certifications: {{I-CAR/Manufacturer/Other}}
- Materials calc method: {{PaintCalcMethod}} (e.g., rate per refinish hr or materials invoice)
- Comparable local shops (optional): {{Shop1}}, {{Shop2}}
