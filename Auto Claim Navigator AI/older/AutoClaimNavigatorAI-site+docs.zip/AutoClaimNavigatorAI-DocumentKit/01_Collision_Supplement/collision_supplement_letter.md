# Collision Supplement Letter (EN)
> Disclaimer (EN): Document preparation assistance only. Not a law firm, not legal advice.
> Aviso (ES): Solo asistencia para preparación de documentos. No es asesoría legal ni bufete.

**To:** {AdjusterName}, {InsurerName}  
**From:** {YourName}, Claim # {ClaimNumber}  
**Vehicle:** {Year} {Make} {Model} {Trim} — VIN {VIN}  
**Date:** 2025-08-22

**Subject:** Collision Supplement — Missing Operations, OEM Requirements, and Rate/Materials Support

Dear {AdjusterName},

Please treat this as a formal supplement request. Based on the repair plan from {ShopName} dated {ShopEstDate} (attached), the following items are required to return the vehicle to pre-loss condition and comply with OEM procedures and safety standards.

## 1) Missing/Under‑scoped Operations
- {Op1}  
- {Op2}  
- {Op3}  
(Add labor hours and line refs if available.)

## 2) OEM/Scan/Calibration Requirements
- {OEMcite1}  
- {OEMcite2}  
(Attach pre/post scans and calibration sheets if available.)

## 3) Labor Rates & Paint Materials
- Body: ${BodyRate}/hr; Refinish: ${RefinishRate}/hr; Frame: ${FrameRate}/hr  
- Materials: ${PaintMaterials} (method: {CalcMethod})

These rates reflect prevailing market conditions in {ZIP} and shop capabilities (certifications: {Certs}).

## 4) Total Requested Supplement
Parts: ${PartsDelta}  
Labor: ${LaborDelta}  
Materials: ${MaterialsDelta}  
**Supplement total:** ${SuppTotal}

Please update the estimate and issue payment or schedule reinspection within {BusinessDays} business days. If anything further is needed, let me know.

Sincerely,  
{YourName}  
{Phone} · {Email}

---
# Carta de Suplemento por Colisión (ES)
> Disclaimer (EN): Document preparation assistance only. Not a law firm, not legal advice.
> Aviso (ES): Solo asistencia para preparación de documentos. No es asesoría legal ni bufete.

**Para:** {AdjusterName}, {InsurerName}  
**De:** {YourName}, Reclamo # {ClaimNumber}  
**Vehículo:** {Year} {Make} {Model} {Trim} — VIN {VIN}  
**Fecha:** 2025-08-22

**Asunto:** Suplemento de colisión — Operaciones faltantes, requisitos OEM y tarifas/materiales

Estimado(a) {AdjusterName},

Trate esta carta como una solicitud formal de suplemento. Con base en el plan de reparación de {ShopName} de fecha {ShopEstDate} (adjunto), se requieren los siguientes elementos para devolver el vehículo a su condición previa a la pérdida y cumplir con procedimientos OEM y estándares de seguridad.

## 1) Operaciones faltantes/subestimadas
- {Op1}  
- {Op2}  
- {Op3}

## 2) Requisitos de OEM/escaneos/calibraciones
- {OEMcite1}  
- {OEMcite2}

## 3) Tarifas de mano de obra y materiales de pintura
- Carrocería: ${BodyRate}/hr; Pintura: ${RefinishRate}/hr; Estructura: ${FrameRate}/hr  
- Materiales: ${PaintMaterials} (método: {CalcMethod})

Estas tarifas reflejan el mercado en {ZIP} y las capacidades del taller (certificaciones: {Certs}).

## 4) Suplemento solicitado
Partes: ${PartsDelta}  
Mano de obra: ${LaborDelta}  
Materiales: ${MaterialsDelta}  
**Total suplemento:** ${SuppTotal}

Favor de actualizar el estimado y emitir el pago o programar reinspección dentro de {BusinessDays} días hábiles.

Atentamente,  
{YourName}  
{Phone} · {Email}
