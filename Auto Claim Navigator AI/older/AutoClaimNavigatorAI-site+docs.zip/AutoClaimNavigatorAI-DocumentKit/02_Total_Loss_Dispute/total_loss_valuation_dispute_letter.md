# Total-Loss Valuation Dispute Letter (EN)
> Disclaimer (EN): Document preparation assistance only. Not a law firm, not legal advice.
> Aviso (ES): Solo asistencia para preparación de documentos. No es asesoría legal ni bufete.

**To:** {AdjusterName}, {InsurerName}  
**From:** {YourName}, Claim # {ClaimNumber}  
**Vehicle:** {Year} {Make} {Model} {Trim} — VIN {VIN}  
**Date:** YYYY-MM-DD

**Subject:** Dispute of Total-Loss Valuation — Corrected Value and Required Adjustments

I dispute the valuation dated {ValuationDate}. The report underprices my vehicle by omitting options/mileage adjustments and using non-comparable listings. Below are the required corrections:

## 1) Options & Mileage
- Options present: {OptionsList} (value adj: ${OptionsAdj})  
- Actual mileage: {Mileage} (adj: ${MileageAdj})

## 2) Comparable Vehicles Matrix
See attached `comps_matrix.csv` with ask/prices, trims, options, mileage, distance, and notes. Non-comparable units removed.

## 3) Taxes, Title, and Fees
ZIP {ZIP} tax rate {TaxRate}%; title/registration ${Fees}. These must be included in settlement per policy/state practice.

**Corrected Actual Cash Value (ACV):** ${CorrectedACV}  
**Difference from insurer valuation:** ${Delta}

Please update the valuation and issue the revised settlement or schedule reinspection within {BusinessDays} business days.

Sincerely,  
{YourName} · {Phone} · {Email}

---
# Carta de Disputa por Pérdida Total (ES)
> Disclaimer (EN): Document preparation assistance only. Not a law firm, not legal advice.
> Aviso (ES): Solo asistencia para preparación de documentos. No es asesoría legal ni bufete.

**Para:** {AdjusterName}, {InsurerName}  
**De:** {YourName}, Reclamo # {ClaimNumber}  
**Vehículo:** {Year} {Make} {Model} {Trim} — VIN {VIN}  
**Fecha:** YYYY-MM-DD

**Asunto:** Disputa de valuación por pérdida total — Valor corregido y ajustes necesarios

Impugno la valuación de fecha {ValuationDate}. El informe subvalora mi vehículo al omitir opciones/ajustes por kilometraje y usar comparables inadecuados. Correcciones:

## 1) Opciones y kilometraje
- Opciones presentes: {OptionsList} (ajuste: ${OptionsAdj})  
- Kilometraje real: {Mileage} (ajuste: ${MileageAdj})

## 2) Matriz de comparables
Vea `comps_matrix.csv` adjunto con precios, versiones, opciones, kilometraje, distancia y notas. Se eliminaron unidades no comparables.

## 3) Impuestos, título y tasas
CP {ZIP} tasa {TaxRate}%; título/registro ${Fees}. Deben incluirse conforme póliza/norma estatal.

**Valor real en efectivo (ACV) corregido:** ${CorrectedACV}  
**Diferencia vs. valuación del asegurador:** ${Delta}

Favor de actualizar la valuación y emitir el acuerdo revisado o programar reinspección en {BusinessDays} días hábiles.
