AutoClaimNavigatorAI — Document Kit (v1) — 2025-08-22
=================================================

This kit contains editable templates for policyholders to prepare auto-claim documentation.
You send these documents to your insurer; this kit is **document preparation only** and is **not legal advice**.

Structure
---------
01_Collision_Supplement/
02_Total_Loss_Dispute/
03_DV_Demand/
04_Rental_Extension/
05_PIP_MedPay/
06_Follow_Through/
Upload_Checklist.md

How to use
----------
1) Open Upload_Checklist.md and gather what you can.
2) Complete the templates in each folder (replace {placeholders}).
3) Export to PDF or send as-is per your insurer's instructions.
4) Use 06_Follow_Through/email_scripts.md for send/follow-up timing.
