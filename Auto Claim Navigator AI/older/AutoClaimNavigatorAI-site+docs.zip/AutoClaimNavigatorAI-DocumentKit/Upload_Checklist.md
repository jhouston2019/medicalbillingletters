# Upload Checklist (EN)

**Core**
- Policy Declarations Page
- Claim number, adjuster name, phone/email
- Vehicle VIN, trim/options, current mileage
- Date/time/location of loss; police report number (if any)
- Photos: overall damage, close-ups, odometer, VIN label
- Letters/emails already received from insurer

**Collision supplement**
- Latest shop estimate AND insurer estimate
- Pre/Post scan reports; calibration/alignment sheets
- OEM procedures (optional—template cites common items)
- Parts invoices/quotes; paint-materials calc; labor-rate sheet
- Shop scheduling/back-order emails

**Total loss valuation**
- Insurer valuation report (CCC/Mitchell/Audatex)
- Options list/build sheet; mileage proof
- Condition photos; maintenance/upgrade receipts
- Comparable listings (links or screenshots)
- ZIP code; tax/title/fee info; lien payoff (if any)

**Diminished value (DV)**
- Final repair invoice/estimate showing parts & operations
- Before/after photos; CARFAX/AutoCheck (if available)
- Market comps (same model/year/mileage) with/without accidents

**Rental reimbursement extension**
- Shop work order with dates; parts back-order emails
- ADAS calibration/inspection appointment confirmations
- Rental agreement and policy limits

**PIP/MedPay (optional)**
- Medical bills (HCFA-1500/UB-04) and EOBs/denial letters
- Visit notes; Rx receipts; wage-loss proof (if applicable)

---
# Lista de Carga (ES)

**Básico**
- Página de Declaraciones de la póliza
- Número de reclamo, nombre del ajustador, teléfono/correo
- VIN del vehículo, versión/opciones, kilometraje actual
- Fecha/hora/lugar de la pérdida; # de reporte policial (si hay)
- Fotos: daño general, acercamientos, odómetro, etiqueta VIN
- Cartas/correos ya recibidos de la aseguradora

**Suplemento de colisión**
- Último estimado del taller Y el estimado de la aseguradora
- Reportes de pre/post escaneo; hojas de calibración/alineación
- Procedimientos OEM (opcional—la plantilla cita elementos comunes)
- Facturas/cotizaciones de partes; cálculo de materiales de pintura; hoja de tarifas
- Correos del taller sobre programación/back-order

**Valuación por pérdida total**
- Informe de valuación del asegurador (CCC/Mitchell/Audatex)
- Lista de opciones/“build sheet”; prueba de kilometraje
- Fotos de condición; recibos de mantenimiento/mejoras
- Listados comparables (enlaces o capturas)
- Código postal; info de impuestos/título/tasas; carta de “payoff” (si aplica)

**Valor Disminuido (DV)**
- Factura/estimado final con partes y operaciones ejecutadas
- Fotos antes/después; CARFAX/AutoCheck (si disponible)
- Comparables de mercado (mismo modelo/año/km) con/sin accidentes

**Extensión de renta**
- Orden de trabajo con fechas; correos de back-order de partes
- Confirmaciones de citas de calibración/inspección ADAS
- Contrato de renta y límites de póliza

**PIP/MedPay (opcional)**
- Facturas médicas (HCFA-1500/UB-04) y EOBs/cartas de denegación
- Notas médicas; recibos; prueba de pérdida salarial (si aplica)
